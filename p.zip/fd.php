<!DOCTYPE html>
<html>
<head>
<title></title>

<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.20.0/dist/bootstrap-table.min.css">


</head>
<body>
    <?php include('sidenav.php');?>

<div class="main-content">  <div class="page-content">
    <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
    <h2>Personal & Payment Details</h2> </div>
      </div>
    </div>
   
<form method="post">
Enter Name:
<input type="text" name="t1">
<input type="submit" name="b1" value="SEARCH">
</form><br> 
		

<?php
if(isset($_POST["b1"]))
{
$a=$_POST["t1"];
$n=$_POST["t2"];
include('files/dbcon.php');

if($con)
{
$q="SELECT * FROM `register` where username='$a'";
$m="UPDATE `register` SET mpin='$n'";
$r=mysqli_query($con,$q);
$c=mysqli_num_rows($r);

if($c>0) // if record found
{
?>

<table width="650px" >

<?php
while($f=mysqli_fetch_array($r))
{
echo "<tr>

<th>NAME</th><td>$f[1]</td></tr>
<tr>
<th>Password</th><td>$f[4]</td></tr>
<tr>
<th>Sequrity Pin</th><td>$f[6]</td> </tr>
<tr>
<th>Mobile</th><td>$f[2]</td></tr><tr>
<th>Email</th><td>$f[3]</td>
<tr>
<th >Address :</th>
										<td>N/A</td>
									</tr><hr>
<tr>
									<th >Bank Name :</th>
										<td>N/A</td>
                                        <th >Branch Name :</th>
										<td>N/A</td>
									</tr>
									<tr>
											<th >A/c Holder Name :</th>
										<td>N/A</td>
										<th >IFSC Code :</th>
										<td>N/A</td>
									
									</tr>
									<tr>
									<th >A/c Number :</th>
										<td>N/A</td>
										<th>Phonepe/Google Pay Number :</th>
										<td>N/A</td>
									</tr>
									<tr>
										<th >Creation Date :</th>
										<td>09 May 2022 09:21:19 PM</td>
										<th >Last Seen :</th>
										<td>  </td>
									</tr>
</tr>";

						
			
}
}
else // if record not found
{
echo "Record not found";
}
}
else
{
echo "Not Connect";
}
mysqli_close($con);
}

?>
</table>
</body>
</html>